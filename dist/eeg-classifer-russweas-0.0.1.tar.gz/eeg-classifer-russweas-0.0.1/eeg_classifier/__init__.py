"""
eeg_classifier.

A set of tools to help design EEG classifier models in Python
"""

__version__ = "0.0.1"
__author__ = 'Russell Weas'
__credits__ = 'The University of Alabama Human Technology Interaction Lab'